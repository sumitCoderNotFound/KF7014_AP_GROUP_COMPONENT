package com.apiauth.API.Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
